"""Original storybook game asset pack. Procedural drawings, no third-party artwork.
All PNGs have transparent padding, ground contact at (width/2, height-8).
Warm upper-left light; isometric ground projection 2:1. Runtime needs no Pillow.
"""
from PIL import Image, ImageDraw
from pathlib import Path
import math, random
OUT=Path(__file__).resolve().parents[1]/'dist/assets/story'
OUT.mkdir(parents=True,exist_ok=True)
random.seed(27)
def canvas(w,h):
 global im,d,W,H
 W,H=w,h;im=Image.new('RGBA',(w,h));d=ImageDraw.Draw(im)
def save(name):im.save(OUT/(name+'.png'))
def p(points,c):d.polygon(points,fill=c)
def l(points,c,w=2):d.line(points,fill=c,width=w)
def r(box,c,rad=0):
 if rad:d.rounded_rectangle(box,radius=rad,fill=c)
 else:d.rectangle(box,fill=c)
def e(box,c):d.ellipse(box,fill=c)
def shade(cx,cy,rx,ry):
 e((cx-rx,cy-ry,cx+rx,cy+ry),'#3c584028');e((cx-rx*.7,cy-ry*.65,cx+rx*.7,cy+ry*.65),'#314b3120')
def leaf(x,y,s=1,c='#79b34e',flip=1):
 p([(x,y),(x-8*s*flip,y-3*s),(x-12*s*flip,y-12*s),(x-3*s*flip,y-10*s)],c);l([(x,y),(x-7*s*flip,y-8*s)],'#a9cf6b',max(1,int(s)))
def flower(x,y,s=1,c='#ec92ad'):
 l([(x,y+13*s),(x,y)],'#659348',max(1,int(2*s)));leaf(x,y+7*s,s*.45)
 for a in range(5):
  q=a*math.pi*2/5;e((x+math.cos(q)*4*s-3*s,y+math.sin(q)*4*s-3*s,x+math.cos(q)*4*s+3*s,y+math.sin(q)*4*s+3*s),c)
 e((x-2*s,y-2*s,x+2*s,y+2*s),'#ffe6a0')
def window(x,y,scale=1,side=False):
 if side:
  p([(x,y),(x+18*scale,y-9*scale),(x+18*scale,y+15*scale),(x,y+24*scale)],'#785b49');p([(x+3*scale,y+2*scale),(x+15*scale,y-4*scale),(x+15*scale,y+13*scale),(x+3*scale,y+19*scale)],'#b7e4dc');l([(x+9*scale,y),(x+9*scale,y+19*scale)],'#fff0c0',2);l([(x+2*scale,y+10*scale),(x+16*scale,y+3*scale)],'#fff0c0',2)
 else:
  p([(x,y),(x+20*scale,y+10*scale),(x+20*scale,y+33*scale),(x,y+23*scale)],'#89634a');p([(x+3*scale,y+5*scale),(x+17*scale,y+12*scale),(x+17*scale,y+28*scale),(x+3*scale,y+21*scale)],'#b8e7db');l([(x+10*scale,y+7*scale),(x+10*scale,y+25*scale)],'#fff0c5',2);l([(x+3*scale,y+13*scale),(x+17*scale,y+20*scale)],'#fff0c5',2)
def cottage(name,stage=0,kind='house'):
 canvas(256,256);shade(127,237,109,16)
 # Raised stone foundation, coherent diagonal walls.
 baseY=220;topY=144-(22 if stage>1 else 0);left=40-(4 if stage>0 else 0);right=214
 p([(left,baseY-40),(126,baseY),(right,baseY-43),(right,baseY-30),(126,baseY+14),(left,baseY-28)],'#b9ad8b')
 p([(left,topY-40),(126,topY),(126,baseY),(left,baseY-40)],'#edc987');p([(126,topY),(right,topY-43),(right,baseY-43),(126,baseY)],'#c49862')
 # Plank joinery, grain and knots.
 for yy in range(topY-35,baseY-40,10):l([(left+2,yy),(124,yy+40)],'#c69561');l([(129,yy+40),(right-1,yy-2)],'#ac7d51')
 for j in range(24):
  x=45+(j*19)%72;y=topY-30+(j*13)%max(8,baseY-topY-9)+(x-40)*.48
  l([(x,y),(x+7,y+3)],'#d3a76a',1)
 # Roof is a curved clipped gambrel profile, with individually shaded shingles.
 ridge=(112,50-(18 if stage>1 else 0));yshift=-18 if stage>1 else 0
 roof1=[(19,topY-39),(48,topY-67),(78,topY-93),(112,50+yshift),(147,69+yshift),(179,topY-35),(130,topY+7)]
 p(roof1,'#a85e57' if kind!='barn' else '#637f75')
 p([(112,50+yshift),(143,35+yshift),(235,topY-82),(225,topY-45),(179,topY-35),(147,69+yshift)],'#e19c79' if kind!='barn' else '#98b19a')
 # Long diagonally sloped tile strips; randomized tiles light edges.
 colors=['#cd826c','#c37765','#dd9477','#bd6b60'] if kind!='barn' else ['#73988b','#80a394','#88ac9c','#638b7f']
 for row in range(5):
  yy=topY-43-row*13;xx=25+row*17
  for col in range(7-row//2):
   x=xx+col*17;y=yy+col*7
   if x<173:
    p([(x,y),(x+14,y+6),(x+23,y-4),(x+9,y-10)],colors[(row+col)%4]);l([(x,y),(x+14,y+6)],'#f3bc8e' if kind!='barn' else '#b5ceaa',1)
 l([(19,topY-38),(130,topY+9),(225,topY-45)],'#6e6d47',5)
 l([(22,topY-34),(130,topY+14),(225,topY-40)],'#f5d79c',3)
 # Chimney, cap, mortar.
 p([(177,65+yshift),(189,59+yshift),(189,104+yshift),(177,110+yshift)],'#a97066');p([(164,59+yshift),(177,65+yshift),(177,110+yshift),(164,103+yshift)],'#d8a181');p([(160,57+yshift),(174,49+yshift),(194,58+yshift),(179,67+yshift)],'#f1cfab')
 for yy in range(72+yshift,103+yshift,9):l([(165,yy),(177,yy+6),(188,yy)],'#e9b89c',1)
 # Rounded door within front wall, frame, metal handle, stone stairs.
 p([(83,baseY-60),(107,baseY-49),(107,baseY-9),(83,baseY-20)],'#7a6650');p([(87,baseY-55),(103,baseY-47),(103,baseY-13),(87,baseY-21)],'#7d9a81')
 l([(94,baseY-50),(94,baseY-20)],'#a9bd94',2);e((98,baseY-32,101,baseY-29),'#f1d27e')
 p([(77,baseY-18),(108,baseY-3),(118,baseY-8),(86,baseY-24)],'#ded2ae');p([(73,baseY-13),(106,baseY+2),(118,baseY-4),(84,baseY-19)],'#c5b995')
 window(49,baseY-81,.88);window(153,baseY-77,1.3,True)
 if stage>=2:
  window(52,baseY-126,.9);window(154,baseY-119,1.05,True)
  p([(75,topY-57),(89,topY-75),(110,topY-66),(110,topY-35)],'#efd2a0');p([(70,topY-57),(87,topY-82),(115,topY-65),(109,topY-60),(88,topY-75),(77,topY-53)],'#a26760');window(83,topY-61,.65)
 if stage>=1:
  # Porch trellis, flower windowbox and side veranda.
  l([(75,baseY-22),(75,baseY-68),(110,baseY-51),(110,baseY-5)],'#9d7d52',4)
  p([(68,baseY-70),(85,baseY-79),(118,baseY-62),(105,baseY-51)],'#dcaa76')
  for x,y in [(51,baseY-55),(59,baseY-51),(68,baseY-47),(184,baseY-61),(197,baseY-67)]:flower(x,y,.55,'#eb8ca4')
 if stage>=3:
  # Wrap-around terrace and decorative garden arch, clearly larger footprint.
  p([(135,226),(211,187),(245,205),(170,245)],'#cfa470')
  for j in range(7):l([(143+j*10,222-j*5),(173+j*10,238-j*5)],'#ecd1a0',2)
  l([(172,230),(172,242),(242,207),(242,195)],'#8c8860',3)
  for j in range(6):l([(181+j*10,226-j*5),(181+j*10,238-j*5)],'#f0dfaf',2)
  r((34,186,39,224),'#6d8f5d');r((57,197,62,236),'#6d8f5d');d.arc((34,174,62,206),180,360,fill='#789b68',width=4)
  for x,y in [(33,188),(38,182),(50,183),(61,198),(161,235),(184,222),(213,207)]:flower(x,y,.65,'#f3b1b3')
 # Ground edging, tidy ornamental planting, stones.
 for x,y in [(33,218),(46,224),(137,235),(217,199)]:
  e((x-9,y-7,x+10,y+3),'#62974f');leaf(x,y,1,'#84b75c');flower(x-2,y-8,.65,'#f9cd72')
 if kind=='barn':
  p([(154,baseY-66),(193,baseY-86),(193,baseY-34),(154,baseY-15)],'#8a624b');l([(158,baseY-62),(189,baseY-39)],'#e5c697',4);l([(158,baseY-22),(189,baseY-81)],'#e5c697',4)
  r((32,baseY-3,54,baseY+8),'#d6b166',3);l([(36,baseY),(50,baseY+5)],'#f1d58d',2)
 if kind=='bakery':
  p([(145,baseY-78),(179,baseY-95),(191,baseY-81),(154,baseY-63)],'#f2dca2')
  for j in range(4):l([(148+j*9,baseY-79-j*4),(157+j*9,baseY-65-j*4)],'#b4828c',6)
  e((160,baseY-107,187,baseY-89),'#9a704b');e((163,baseY-105,184,baseY-91),'#e8b96f');l([(170,baseY-103),(175,baseY-94)],'#fff0ba',2)
 save(name)
for i in range(4):cottage('house'+str(i),i)
cottage('barn',1,'barn');cottage('bakery',1,'bakery')
# Decorative flora with layered leaves and scattered petals.
for name in ['fruitTree','sapling','bush','flowerpatch','grass','reeds','mushrooms','rock']:
 canvas(128,160 if name=='fruitTree' else 96);ground=H-8;shade(64,ground,45,7)
 if name=='fruitTree':
  p([(57,150),(61,77),(69,73),(72,150)],'#9b744e');l([(65,131),(42,99)],'#9b744e',6);l([(66,116),(85,91)],'#aa8253',5);l([(60,141),(62,90)],'#c2945c',3)
  for x,y,rad,c in [(35,76,27,'#477f48'),(81,79,32,'#4a8750'),(62,46,36,'#589b53'),(31,48,23,'#71b05b'),(92,47,22,'#71aa55'),(57,26,23,'#8cbe65')]:e((x-rad,y-rad*.8,x+rad,y+rad*.8),c)
  for j in range(65):
   x=random.randrange(22,106);y=random.randrange(25,91)
   if ((x-63)/49)**2+((y-57)/39)**2<1:e((x,y,x+5,y+3),'#9bc97a' if j%3 else '#4b8c48')
  for x,y in [(31,52),(56,78),(91,59),(69,39),(40,84),(99,79)]:e((x-5,y-5,x+6,y+6),'#db8568');e((x-3,y-4,x,y-1),'#ffd08e');l([(x,y-5),(x+2,y-9)],'#727d45',2)
 elif name=='sapling':
  l([(63,88),(63,34)],'#98774c',4)
  for x,y,rad,c in [(51,53,19,'#68a453'),(75,47,18,'#83b85a'),(63,31,20,'#a3c86c')]:e((x-rad,y-rad,x+rad,y+rad),c)
 elif name=='bush':
  for x,y,rad,c in [(38,72,21,'#4d894b'),(79,72,24,'#57974f'),(60,58,25,'#7db45c'),(39,59,13,'#99c776')]:e((x-rad,y-rad*.7,x+rad,y+rad*.7),c)
  for x,y in [(36,57),(61,65),(82,70),(48,75),(71,52)]:e((x,y,x+5,y+5),'#d5a7c1')
 elif name=='flowerpatch':
  for j in range(15):
   x=20+(j*23)%90;y=45+(j*17)%32;leaf(x,y+8,.9,['#80b75b','#609947'][j%2]);flower(x,y,1.0,['#ef9bb2','#f9d578','#f4e9c2','#b7a1d2'][j%4])
 elif name=='grass':
  for j in range(23):
   x=18+(j*13)%94;y=66+(j*19)%20;p([(x-3,y),(x-7,y-13),(x,y-5),(x+4,y-22),(x+4,y-5),(x+11,y-12),(x+7,y)],['#82b260','#a6c978','#70a25a'][j%3])
 elif name=='reeds':
  for j in range(9):
   x=35+j*7;y=83+(j%3)*2;l([(x,y),(x-4,32+j%3*8)],'#7c9c52',2);r((x-7,20+j%3*8,x-2,39+j%3*8),'#9f7d52',3);l([(x,y),(x-12,57)],'#a0bd67',2)
 elif name=='mushrooms':
  for x,y,s in [(45,68,1.1),(76,77,.8),(62,54,.55)]:
   r((x-3*s,y,x+3*s,y+16*s),'#ead5a1');d.pieslice((x-15*s,y-14*s,x+15*s,y+8*s),180,360,fill='#d58b78');e((x-5*s,y-10*s,x,y-6*s),'#ffe6ba');e((x+5*s,y-6*s,x+9*s,y-3*s),'#ffe6ba')
 elif name=='rock':
  p([(24,77),(31,57),(61,44),(89,53),(106,78),(75,88),(40,86)],'#91a093');p([(31,57),(61,44),(89,53),(72,67),(42,69)],'#c2c9ae');p([(72,67),(89,53),(106,78),(75,88)],'#7c8d84');l([(44,70),(49,80),(64,82)],'#aeb8a0',2);leaf(31,83,.8)
 save(name)
# Small handcrafted farm props.
for name in ['well','fountain','cart','mailbox','scarecrow','hay','sign','trough','flowerstall']:
 canvas(192 if name in ['flowerstall','fountain'] else 128,192 if name in ['flowerstall','fountain'] else 128);cx=W//2;g=H-8;shade(cx,g,W*.4,9)
 if name=='well':
  e((29,83,101,119),'#9ca895');r((29,82,101,101),'#aeba9d');e((29,70,101,104),'#d3d5b4');e((37,76,93,98),'#587a77');e((43,79,90,92),'#76b5b3')
  for x in [30,98]:r((x,41,x+4,96),'#9c784e')
  p([(18,47),(61,18),(112,44),(68,72)],'#b97969');p([(61,18),(71,12),(120,36),(112,44)],'#e0a47b');l([(18,47),(68,72),(120,36)],'#785f50',3);l([(65,55),(65,89)],'#ae925d',2);r((58,84,71,97),'#bc9764',2)
 elif name=='fountain':
  e((21,133,171,180),'#97ad9c');e((26,127,166,170),'#d2d9b5');e((37,134,155,163),'#78beb6');e((44,140,150,159),'#b2e0c7');r((88,94,105,151),'#b3c8b0');e((58,83,135,111),'#cddab9');e((65,86,128,103),'#88c9bd');p([(89,91),(97,52),(107,91)],'#c5d6b5');e((87,44,108,64),'#eed596')
  for x in [76,119]:d.arc((x-17,63,x+12,134),180,340,fill='#dcf7da',width=3)
  for x,y in [(33,153),(50,165),(147,149),(132,168)]:flower(x,y,1,'#e7a0b4')
 elif name=='cart':
  for x,y in [(36,105),(96,91)]:e((x-12,y-14,x+12,y+14),'#806b4c');e((x-8,y-10,x+8,y+10),'#d4ad72');l([(x-8,y),(x+8,y)],'#8a714d',2);l([(x,y-10),(x,y+10)],'#8a714d',2)
  p([(21,78),(76,50),(108,68),(54,98)],'#ead0a0');p([(21,78),(54,98),(54,112),(21,94)],'#b78b5d');p([(54,98),(108,68),(108,84),(54,112)],'#c89d68');l([(27,95),(8,86)],'#967750',4)
  for x,y in [(39,72),(59,67),(75,76),(90,65)]:flower(x,y,1.2,['#f2c26a','#ed9db4'][x%2])
 elif name=='mailbox':
  r((61,62,68,119),'#a58058');r((37,43,79,75),'#7faaa0',7);p([(79,44),(101,34),(101,63),(79,75)],'#558a87');d.arc((38,35,79,60),180,360,fill='#aad0bb',width=5);p([(52,54),(69,57),(69,66),(52,63)],'#f5e3bc');l([(52,54),(61,61),(69,57)],'#baae87',1);l([(88,37),(88,16)],'#a77558',3);p([(89,16),(106,16),(106,27),(89,27)],'#dc988b')
 elif name=='scarecrow':
  l([(62,56),(62,119)],'#ab8755',5);l([(25,64),(102,52)],'#ab8755',5);p([(47,56),(80,53),(87,92),(43,97)],'#8ca89b');p([(47,56),(53,72),(76,70),(80,53)],'#e9cb8e');e((45,25,82,60),'#f1d496');p([(41,29),(48,12),(75,12),(85,29)],'#c59859');e((31,25,92,34),'#dfb86f');e((55,39,58,42),'#5d6750');e((70,37,73,40),'#5d6750');l([(60,49),(67,48)],'#a97b61',2);l([(40,78),(23,87)],'#e3bf79',4);l([(82,75),(99,81)],'#e3bf79',4)
 elif name=='hay':
  r((22,66,104,117),'#caa552',12);e((19,66,59,117),'#e8c96b');e((27,74,51,110),'#d3ac52');e((33,82,45,103),'#f5dc88')
  for j in range(11):l([(51,70+j*4),(99,69+j*4)],'#e6c577',1)
  l([(70,67),(70,117)],'#9f9255',3);l([(86,67),(86,117)],'#9f9255',3)
 elif name=='sign':
  r((61,67,68,119),'#a78355');p([(26,39),(95,44),(108,60),(92,75),(26,70)],'#ceab72');l([(31,44),(92,49)],'#eed8a3',2);l([(33,62),(83,66)],'#b68f5f',2);p([(50,54),(71,55),(71,50),(83,60),(70,66),(70,61),(50,60)],'#f9e8b9')
 elif name=='trough':
  p([(15,85),(81,53),(113,69),(47,105)],'#b79365');p([(15,85),(47,105),(47,120),(15,101)],'#a78359');p([(47,105),(113,69),(113,84),(47,120)],'#927250');p([(25,86),(82,60),(102,70),(47,98)],'#8cc8be');l([(25,87),(80,62)],'#d1e9ca',2)
 elif name=='flowerstall':
  for x,y in [(22,70),(157,68),(93,101)]:r((x,y,x+5,y+71),'#a38458')
  p([(13,70),(83,30),(175,70),(101,112)],'#fff0c2')
  for j in range(6):p([(13+j*12,70-j*7),(25+j*12,63-j*7),(113+j*11,105-j*6),(101+j*11,112-j*6)],'#b3bed4' if j%2 else '#e5a1ae')
  p([(28,135),(94,170),(162,132),(95,99)],'#efd1a1');p([(28,135),(94,170),(94,184),(28,151)],'#ba9266');p([(94,170),(162,132),(162,149),(94,184)],'#997e5b')
  for x,y in [(48,122),(69,130),(92,137),(117,124),(139,112)]:r((x-8,y,x+8,y+15),'#c98d71',3);flower(x,y-5,1.5,['#f4c574','#ed9cae','#bcadd8'][x%3])
 save(name)
# Crops: four structurally different stages, type-specific foliage/fruit.
for crop in ['carrot','tomato','strawberry','pumpkin','corn','sunflower']:
 for stage in range(4):
  canvas(64,96);shade(32,87,24,5)
  if stage==0:
   e((24,81,41,88),'#a47e4d');e((27,79,34,83),'#e8bf78');e((36,81,42,84),'#d5a362')
  else:
   top=72-stage*13;l([(32,86),(32,top)],'#578b43',3)
   for j in range(stage+1):leaf(32,82-j*9,.7+stage*.15,'#75ab4f',(-1)**j)
   if stage>=2:
    if crop in ['corn','sunflower']:
     l([(32,83),(32,20 if stage==3 else 42)],'#6b9a45',4)
     for yy,fl in [(39,1),(55,-1),(70,1)]:leaf(32,yy,1.2,'#8db958',fl)
    if crop=='tomato':
     l([(19,87),(28,40)],'#ae9363',2);l([(42,87),(35,39)],'#ae9363',2)
    if stage==2:
     for x,y in [(25,47),(37,54)]:flower(x,y,.55,'#f5d890')
   if stage==3:
    if crop=='carrot':
     p([(19,68),(23,59),(42,59),(45,68),(34,90),(29,89)],'#e79b51');l([(28,65),(37,67)],'#f5bc6d',2);l([(27,75),(36,77)],'#d78142',2)
     for x in [24,32,39]:leaf(x,61,1.0,'#6ba94c',1 if x<32 else -1)
    elif crop=='pumpkin':
     for x,c in [(22,'#d98a42'),(32,'#e9a04a'),(42,'#d69240')]:e((x-10,63,x+10,87),c)
     l([(32,64),(30,58),(35,56)],'#658b43',3);l([(32,68),(32,82)],'#f6bd61',2)
    elif crop=='tomato':
     for x,y in [(22,63),(42,54),(35,76)]:e((x-8,y-8,x+8,y+8),'#d86d58');e((x-4,y-5,x,y-2),'#f4a27f');p([(x-5,y-7),(x,y-11),(x+5,y-7),(x,y-6)],'#4f8a40')
    elif crop=='strawberry':
     for x,y in [(19,75),(38,67),(42,82)]:
      p([(x-7,y-5),(x,y-8),(x+7,y-5),(x+6,y+2),(x,y+9),(x-6,y+2)],'#d9757d');p([(x-6,y-7),(x,y-11),(x+6,y-7),(x,y-5)],'#6b9f43')
      for dx,dy in [(-3,0),(2,2),(0,5)]:r((x+dx,y+dy,x+dx+1,y+dy+1),'#ffdf9e')
    elif crop=='corn':
     for x,y in [(25,47),(39,65)]:
      e((x-5,y-12,x+5,y+12),'#f0c657')
      for dy in range(-8,9,4):l([(x-3,y+dy),(x+3,y+dy)],'#ffe289',2)
      p([(x-7,y+11),(x-10,y-2),(x,y+7),(x+9,y-5),(x+6,y+12)],'#76a649')
    elif crop=='sunflower':
     for a in range(12):
      q=a*math.pi/6;x=32+math.cos(q)*12;y=23+math.sin(q)*12;e((x-5,y-6,x+5,y+6),'#f0c654')
     e((23,14,41,32),'#a77943');e((26,17,38,29),'#bf9450')
     for x,y in [(29,20),(34,20),(31,25),(36,26)]:r((x,y,x+1,y+1),'#efc77a')
  save(crop+str(stage))
# Animal frames: readable personalities, shape anatomy, nuanced ear/wing/leg changes.
for animal in ['chicken','rabbit','sheep','duck']:
 for frame in range(3):
  canvas(80,80);shade(40,71,27,5);bob=frame%2*2
  if animal=='chicken':
   l([(35,60),(33+frame,71)],'#cb9953',3);l([(48,60),(48-frame,71)],'#cb9953',3)
   p([(20,46),(10,30),(22,35),(18,21),(31,35)],'#c3a180');e((19,34+bob,63,65+bob),'#fff0cc');e((24,34+bob,51,56+bob),'#fff8df');e((45,19+bob,68,44+bob),'#fff3d7');e((49,13+bob,56,24+bob),'#d77a75');e((55,11+bob,62,23+bob),'#e79185');p([(66,29+bob),(76,33+bob),(66,37+bob)],'#e8b459');e((60,28+bob,63,31+bob),'#4c5f50');d.arc((28,39+bob,50,58+bob),20+frame*15,160,fill='#d9c39b',width=2)
  elif animal=='rabbit':
   e((17,41+bob,60,68+bob),'#dbd1c2');e((48,30+bob,73,57+bob),'#f1e4d3');e((13,45+bob,29,61+bob),'#f8edda');e((50,3+frame*3,59,38+bob),'#ebddcb');e((62,5,71,37+bob),'#e7dac8');e((53,8+frame*3,56,31),'#d2a4a3');e((65,9,68,30),'#d2a4a3');e((64,40+bob,67,44+bob),'#526254');e((71,46+bob,76,50+bob),'#ca9594');e((28-frame*2,62,42,73),'#e9decb');e((56+frame,61,68,70),'#f1e5d3')
  elif animal=='sheep':
   for x in [25,53]:r((x,58,x+6,71),'#8c7d70',2)
   for x,y,rad in [(24,47,13),(36,38,14),(50,42,15),(56,53,13),(39,56,16),(23,57,11)]:e((x-rad,y-rad,x+rad,y+rad),'#f2e8d0');d.arc((x-rad+4,y-rad+4,x+rad-4,y+rad-4),200,300,fill='#d6d2ba',width=2)
   e((52,34+bob,73,61+bob),'#ae9f8e');e((48,30+bob,62,40+bob),'#9c8c7d');e((65,30+bob,79,40+bob),'#a99a87');e((59,43+bob,62,46+bob),'#44564a');e((68,43+bob,71,46+bob),'#44564a');e((64,53+bob,68,56+bob),'#766b60');e((53,26+bob,73,39+bob),'#fff2d9')
  else:
   e((14,63,69,74),'#b7dcce70');d.arc((7,60,75,78),0,160,fill='#d8f1dc',width=2);p([(24,51),(10,43),(14,57),(28,64)],'#d5d9bd');e((21,43+bob,64,68+bob),'#f3e9ba');e((44,25+bob,66,48+bob),'#7eac88');l([(49,45+bob),(62,47+bob)],'#f9ebc5',3);p([(64,35+bob),(77,38+bob),(76,43+bob),(64,42+bob)],'#e5b25b');e((59,32+bob,62,35+bob),'#405a48');d.arc((29,44+bob,53,61+bob),0,160,fill='#d4c79c',width=2)
  save(animal+str(frame))
# Directional explorer; companion aesthetic, stitched clothes, small satchel.
for direction in ['front','back','left','right']:
 for frame in range(2):
  canvas(64,96);shade(32,87,21,5);bob=frame*2
  r((20,73,28,88-frame*3),'#657574',3);r((37,73,45,85+frame*2),'#657574',3);r((17,85-frame*3,29,90-frame*3),'#8e785e',2);r((36,84+frame*2,48,89+frame*2),'#8e785e',2)
  r((17,44+bob,48,77+bob),'#7ca6a0',10);r((15,50+bob,22,69+bob),'#e8cba2',3);r((44,50+bob,51,69+bob),'#e8cba2',3)
  e((17,19+bob,49,52+bob),'#efd5ac');r((16,23+bob,21,39+bob),'#a47953',3);r((44,22+bob,49,39+bob),'#a47953',3)
  e((8,18+bob,57,32+bob),'#dbb879');r((17,8+bob,47,24+bob),'#e9c98c',7);r((17,20+bob,47,24+bob),'#799f75');l([(22,10+bob),(36,10+bob)],'#ffe4ac',2)
  if direction=='back':r((20,29+bob,45,45+bob),'#a27b55',6);r((22,51+bob,45,74+bob),'#b49b69',4);r((26,55+bob,41,65+bob),'#c7b077',3)
  else:
   eyes=[25,39] if direction=='front' else ([23] if direction=='left' else [42])
   for x in eyes:e((x,34+bob,x+3,38+bob),'#425a50')
   l([(30,43+bob),(35,43+bob)],'#b98a70',2);r((23,54+bob,42,72+bob),'#a5c3ad',3);r((24,58+bob,30,64+bob),'#d0d8ae',2);l([(21,46+bob),(45,72+bob)],'#b09464',3);r((42,63+bob,53,77+bob),'#b49565',3)
  save('player_'+direction+str(frame))
print('Original story assets:',len(list(OUT.glob('*.png'))))
# Optional upgraded learning-space art: same 256px ground anchor as the homes.
cottage('seedhouse',0)
cottage('workshop',1,'barn')
canvas(256,256);shade(128,238,113,15)
p([(24,169),(128,222),(235,168),(235,201),(128,247),(24,197)],'#94aa91')
p([(24,169),(128,221),(128,236),(24,185)],'#d3c39b');p([(128,221),(235,168),(235,184),(128,236)],'#a0b391')
# Tall glazed arch segments along a single isometric prism.
p([(25,170),(34,109),(58,77),(89,58),(128,58),(128,221)],'#c1e3cc');p([(128,58),(159,73),(201,94),(226,126),(235,168),(128,221)],'#86c8b9')
p([(34,109),(58,77),(89,58),(128,58),(159,73),(201,94),(226,126),(128,176)],'#b7e4d2')
for x,y in [(37,142),(62,156),(91,169),(149,170),(176,155),(204,139)]:
 r((x-9,y+12,x+9,y+31),'#c99371',3);l([(x,y+16),(x,y-18)],'#628f46',3)
 for yy,flip in [(y-6,1),(y+5,-1)]:leaf(x,yy,1.1,'#75a956',flip)
 flower(x,y-19,.9,['#efb283','#d6add1','#f3d17e'][x%3])
for pts in [[(25,170),(128,221),(235,168)],[(34,109),(128,158),(226,126)],[(58,77),(128,112),(201,94)],[(128,58),(128,221)],[(70,68),(70,192)],[(183,85),(183,194)],[(37,135),(128,182),(232,146)]]:l(pts,'#e9ecd2',4)
# Thin reflection highlights on glass, curved ridge, stone threshold.
for x,y in [(47,126),(84,115),(146,144),(197,118)]:l([(x,y),(x+8,y-15)],'#edfff0',3)
p([(138,190),(159,179),(159,220),(138,230)],'#6e9f91');p([(142,193),(155,186),(155,211),(142,218)],'#c1e6cc');l([(148,190),(148,216)],'#e9ecd0',2);p([(136,230),(160,218),(171,224),(146,236)],'#e2d8b2')
for x,y in [(29,211),(51,224),(215,203)]:flower(x,y,1.2,'#eb9fb0')
save('greenhouse')
# Market canopy, visible baskets of produce, chalkboard, bunting.
canvas(256,256);shade(128,238,112,15)
for x,y in [(30,104),(211,100),(128,147)]:r((x,y,x+6,y+90),'#9c7c53')
p([(14,100),(106,49),(237,101),(139,158)],'#f8e9bd')
for j in range(8):
 x=14+j*12;y=100-j*6.6;p([(x,y),(x+12,y-6.6),(151+j*12,151-j*6.6),(139+j*12,158-j*6.6)],'#dc8e82' if j%2==0 else '#fff1c5')
l([(14,102),(139,160),(237,103)],'#a68365',3)
for j in range(8):e((15+j*15,100+j*7,32+j*15,114+j*7),'#e3a395' if j%2==0 else '#fff1c5')
p([(30,184),(128,233),(225,182),(128,133)],'#e4c394');p([(30,184),(128,233),(128,250),(30,201)],'#ba8d61');p([(128,233),(225,182),(225,199),(128,250)],'#a87b57')
for x,y,col in [(55,174,'#dfa25a'),(88,188,'#d77b67'),(128,194,'#bf9db7'),(161,178,'#9fbd70'),(193,161,'#e9c47b')]:
 p([(x-16,y),(x,y-8),(x+16,y),(x,y+9)],'#b68b5b');p([(x-16,y),(x,y+9),(x,y+17),(x-16,y+8)],'#bd9562');p([(x,y+9),(x+16,y),(x+16,y+8),(x,y+17)],'#9e7c50')
 for dx,dy in [(-7,-1),(1,-4),(8,1),(0,4)]:e((x+dx-5,y+dy-5,x+dx+5,y+dy+5),col);e((x+dx-3,y+dy-4,x+dx,y+dy-2),'#ffe3a4')
# Suspended seed-shaped wooden sign.
l([(108,120),(108,140)],'#967852',2);e((87,134,132,157),'#e6c68b');leaf(109,153,.8,'#7e9f58')
save('market')
canvas(256,256);shade(128,237,110,13)
p([(15,184),(127,240),(242,182),(128,125)],'#d7bdab');p([(15,184),(127,240),(127,250),(15,196)],'#b18d8e');p([(127,240),(242,182),(242,195),(127,250)],'#90788a')
for j in range(10):l([(29+j*10,181-j*5),(135+j*10,232-j*5)],'#ead4ba',2)
for x,y in [(34,98),(220,98)]:r((x,y,x+6,190),'#8e8496');e((x-6,y-15,x+12,y+5),'#f8dba0')
l([(38,103),(128,124),(223,103)],'#918497',3)
for x,y,col in [(61,109,'#df9eaa'),(91,116,'#f0ce86'),(128,120,'#a8c1ad'),(160,115,'#c3afce'),(193,108,'#e6b495')]:p([(x-8,y),(x+8,y+1),(x,y+22)],col)
# Octagonal star podium and a little standing microphone.
e((92,167,168,199),'#9d8fab');e((92,160,168,190),'#c5b6ce')
pts=[]
for i in range(10):a=-math.pi/2+i*math.pi/5;rad=31 if i%2==0 else 14;pts.append((130+math.cos(a)*rad,144+math.sin(a)*rad))
p(pts,'#f5d58b');l([(181,183),(181,147)],'#747f82',3);e((176,139,185,151),'#7d8a89')
for x,y in [(41,190),(59,199),(206,190),(184,203)]:flower(x,y,1.3,'#eb9fb2')
save('stage')
# High-detail grove variants retain the same 128x160 tree proportions.
for name in ['oak','pine','flowerTree']:
 canvas(128,176);shade(64,168,48,8);p([(56,165),(60,81),(69,77),(73,165)],'#9d7650');l([(60,147),(62,90)],'#c69a63',3)
 if name=='pine':
  for yy,wide in [(109,48),(83,39),(59,30),(37,20)]:
   p([(64,yy-34),(64-wide,yy+20),(43,yy+18),(34,yy+28),(70,yy+32),(64+wide,yy+16)],'#438568');p([(64,yy-34),(64-wide+7,yy+17),(58,yy+11),(64,yy+19)],'#70a47a');l([(64,yy-27),(52,yy-3)],'#9ac08a',2)
 else:
  pal=['#488a4b','#5c9e4f','#74b45a','#99c975'] if name=='oak' else ['#c57f96','#dc9bad','#e9b0bc','#f5c7cc']
  for x,y,rad,idx in [(31,101,25,0),(84,102,31,0),(52,79,36,1),(85,65,28,2),(37,60,25,2),(59,38,26,3)]:
   # Slightly scalloped silhouette rather than a uniform sphere.
   for q in range(9):a=q*math.pi*2/9;xx=x+math.cos(a)*rad*.53;yy=y+math.sin(a)*rad*.48;e((xx-rad*.55,yy-rad*.5,xx+rad*.55,yy+rad*.5),pal[idx])
  for j in range(80):
   x=random.randrange(18,110);y=random.randrange(30,125)
   if ((x-64)/48)**2+((y-78)/52)**2<1:e((x,y,x+4,y+2),pal[3] if j%2 else pal[1])
  if name=='flowerTree':
   for x,y in [(35,64),(80,40),(94,90),(44,106),(64,79)]:flower(x,y,.45,'#ffe4cc')
 save(name)
print('Full story asset pack:',len(list(OUT.glob('*.png'))))
